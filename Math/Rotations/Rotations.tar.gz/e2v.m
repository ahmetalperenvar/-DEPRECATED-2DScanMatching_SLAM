function ea = e2v(th,axis)
%Transform the rotation theta TH over the axis AXIS into a rotation vector



end